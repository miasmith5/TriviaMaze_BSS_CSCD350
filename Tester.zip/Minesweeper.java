
import java.util.LinkedList;
import java.util.Scanner;

public class Minesweeper {

	private class Cell {	
		public int max = 8;
		public char[][] array;
		
		public Cell(char[][] array) {
			this.max = 0;
			this.array = array;
		}
		
	}
	
	private LinkedList<Cell> fields;;

	public Minesweeper() {
		this.fields = new LinkedList<Cell>();
	}
	
	public void fieldCount() {
		while(this.fields.peek().max <= 8) {
			this.fields.addLast(this.cellCount(this.fields.poll()));
		}
	}
	
	private Cell cellCount(Cell cell) {
		char[][] array = cell.array;
		for(int i = 0; i < array.length; i++) {
			for(int j = 0; j < array[i].length; j++) {
				if(array[i][j] != '*') {
					array[i][j] = this.countMines(array, i, j);
				}
			}
		}
		cell.array = array;
		cell.max++;
		return cell;
	}
	
	public void readArray(Scanner s) {
		while(s.hasNextLine()) {
			String fl = s.nextLine();
			String[] nm = fl.split(" ");
			int n = Integer.parseInt(nm[0]);
			int m = Integer.parseInt(nm[1]);
			if(n != 0 && m != 0) {
				char[][] field = new char[n+2][m+2];
				for(int x = 0; x < n && s.hasNextLine(); x++) {
					String line = s.nextLine();
					for(int y = 0; y < line.length(); y++) {
						field[x][y] = line.charAt(y);
					}
				}
				this.fields.add(new Cell(field));
			} 
		}
	}

	private char countMines(char[][] arr, int i, int j) {
		int mines = 0;
		if((i-1) >= 0 && (j-1) >= 0 && arr[i-1][j-1] == '*')
			mines++;
		if((i-1) >= 0 && arr[i-1][j] == '*')
			mines++;
		if((i-1) >= 0 && (j+1) < arr[0].length && arr[i-1][j+1] == '*')
			mines++;
		if((j-1) >= 0 && arr[i][j-1] == '*')
			mines++;
		if((j+1) < arr[0].length && arr[i][j+1] == '*')
			mines++;
		if((i+1) < arr.length && j-1 >= 0 && arr[i+1][j-1] == '*')
			mines++;
		if((i+1) < arr.length && arr[i+1][j] == '*')
			mines++;
		if((i+1) < arr.length && j+1 < arr[0].length && arr[i+1][j+1] == '*')
			mines++;
		String s = "" + mines;
		return s.charAt(0);
	} // Ian

	public String printFields() {
		String result = "";	
		for(int i = 0; i < this.fields.size(); i++) {
			result += "Field #" + (i + 1) + ":\r\n";
			char[][] arr = this.fields.get(i).array;
			
				for(int row = 0; row < arr.length -2; row++) {
					for(int col = 0; col < arr[0].length -2; col++) {
						result += arr[row][col];
					}
					result += "\r\n";
				}
				result += "\r\n";
			}
		return result;
	} // Ian
	
}
