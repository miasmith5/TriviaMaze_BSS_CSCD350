
import java.util.Scanner;
import java.io.File;

public class Tester {

	public static void main(String[] args) {

		Minesweeper minesweeper = new Minesweeper();
      
		File file = new File("C:\\Users\\Yousef\\eclipse-workspace\\CSCD350\\src\\input.txt");
		Scanner myScanner = null;
      
      
		try {
			myScanner = new Scanner(file);
		} catch (Exception e) {
			System.out.println("File not found.");
		}
		
		while(myScanner.hasNextLine()) {
			System.out.println(myScanner.nextLine());
		}
		try {
			myScanner = new Scanner(file);
		} catch (Exception e) {
			System.out.println("File not found.");
		}
		
		minesweeper.readArray(myScanner);
		minesweeper.fieldCount();
		System.out.println(minesweeper.printFields());
	}

}
